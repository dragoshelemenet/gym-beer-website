#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f index.html || ! -f scripts/check-site.py || ! -d assets/images ]]; then
  echo "ERROR: Run this installer in the GYM BEER website repository root." >&2
  exit 1
fi
if [[ "${GYM_BEER_DRY_RUN:-0}" != "1" ]]; then
  if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "ERROR: This folder isn't a Git repository." >&2
    exit 1
  fi
  if [[ "$(git branch --show-current)" != "main" ]]; then
    echo "ERROR: Open the main branch in Codespaces before running this update." >&2
    exit 1
  fi
  if ! git diff --cached --quiet; then
    echo "ERROR: You have previously staged changes. Commit or unstage them first so this update won't include them." >&2
    exit 1
  fi
fi
python3 - <<'PY'
from pathlib import Path
import json
import re

root=Path.cwd()
removed=['shop-interior-vertical','bottled-beer-display','beer-taps-detail','draft-selection-wall']

# Keep every other image and section. Replace featured images with existing, approved photos.
page_changes={
    'index.html':{'beer-taps-detail':'beer-assortment-wall','draft-selection-wall':'holz-taps-snack'},
    'bauturi/index.html':{'beer-taps-detail':'beer-assortment-wall'},
    'locatii/botanica/index.html':{'shop-interior-vertical':'shop-interior-wide'},
}
for file,replacements in page_changes.items():
    path=root/file
    text=path.read_text(encoding='utf-8')
    for old,new in replacements.items():
        text=text.replace(old,new)
    path.write_text(text,encoding='utf-8')

# Drop exact gallery tiles (no empty slots or broken photos).
path=root/'galerie/index.html'
text=path.read_text(encoding='utf-8')
for slug in removed:
    pattern=r'<a href="\.\./assets/images/'+re.escape(slug)+r'-1600\.webp" class="gallery-tile".*?</a>'
    text,count=re.subn(pattern,'',text,count=1)
    if count!=1 and slug in text:
        raise SystemExit(f'Could not clean gallery tile: {slug}')
text=text.replace('Toate cele 40 de fotografii din arhiva primită.','36 de fotografii selectate din arhiva GYM BEER.')
text=text.replace('<h2>Magazinele</h2><span>8 fotografii</span>','<h2>Magazinele</h2><span>7 fotografii</span>')
text=text.replace('<h2>Bere & băuturi</h2><span>16 fotografii</span>','<h2>Bere & băuturi</h2><span>13 fotografii</span>')
assert text.count('class="gallery-tile"') == 36, 'Expected exactly 36 photos in gallery'
path.write_text(text,encoding='utf-8')

# Remove outdated source records from the photo manifest.
path=root/'assets/image-index.json'
index=json.loads(path.read_text(encoding='utf-8'))
index=[record for record in index if record.get('slug') not in removed]
assert len(index)==36, 'Expected 36 photo records'
path.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

path=root/'README.md'
readme=path.read_text(encoding='utf-8')
readme=readme.replace('7 pagini, imagini reale din arhiva primită','7 pagini, 36 de fotografii din arhiva primită')
if 'git pull --ff-only origin main && bash scripts/start-preview.sh' not in readme:
    readme=readme.replace('## Pornește în GitHub Codespaces','## Pornește în GitHub Codespaces\n\nUltima versiune poate fi preluată și pornită astfel:\n\n```bash\ngit pull --ff-only origin main && bash scripts/start-preview.sh\n```\n\nFotografiile eliminate la cerere au fost scoase complet din galerie și din folderul de imagini.')
path.write_text(readme,encoding='utf-8')

for slug in removed:
    for size in ('760','1600'):
        (root/'assets/images'/f'{slug}-{size}.webp').unlink(missing_ok=True)

for page in root.rglob('*.html'):
    source=page.read_text(encoding='utf-8')
    for slug in removed:
        if slug in source:
            raise SystemExit(f'Deleted photo still referenced: {page} -> {slug}')
print('Removed 4 photos (8 WebP sizes), updated pages and gallery; 36 gallery items remain.')
PY

# Remove the tracked outdated installation archive so deleted photos cannot be reintroduced from it.
if [[ "${GYM_BEER_DRY_RUN:-0}" != "1" ]]; then
  for asset in shop-interior-vertical bottled-beer-display beer-taps-detail draft-selection-wall; do
    for size in 760 1600; do
      git add -u -- "assets/images/${asset}-${size}.webp"
    done
  done
  if git ls-files --error-unmatch GYM_BEER_Codespaces_Ready.zip >/dev/null 2>&1; then
    rm -f GYM_BEER_Codespaces_Ready.zip
    git add -u -- GYM_BEER_Codespaces_Ready.zip
  fi
fi

python3 scripts/check-site.py

if [[ "${GYM_BEER_DRY_RUN:-0}" == "1" ]]; then
  echo 'PASS: local dry-run; no Git writes.'
  exit 0
fi

git add -- index.html bauturi/index.html locatii/botanica/index.html galerie/index.html assets/image-index.json README.md
if git diff --cached --quiet; then
  echo 'No further changes to publish.'
else
  git commit -m 'Remove four rejected GYM BEER photos and clean gallery'
  git push origin HEAD:main
fi
printf '\nUpdated. Refresh the port 3000 website in your browser (hard refresh if cached).\n'
