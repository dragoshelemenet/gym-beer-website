GYM BEER — Remove 4 photos (Codespaces patch)

1. Upload GYM_BEER_Remove_4_Photos_Update.zip to the ROOT of your Codespace.
2. Run in the terminal:
   git pull --ff-only origin main && unzip -o GYM_BEER_Remove_4_Photos_Update.zip -d . && bash gymbeer-v2/install.sh
3. Refresh the existing port 3000 preview.

Photos deleted (each with both 760 px and 1600 px versions):
- shop-interior-vertical
- bottled-beer-display
- beer-taps-detail
- draft-selection-wall

These are also removed from the gallery and image index. Featured photos on the homepage,
drinks page and Botanica page use existing alternative photos. Other content stays intact.

The script runs python3 scripts/check-site.py then creates a git commit and pushes it to main.
