#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ ! -f index.html || ! -f assets/site.css || ! -d assets/images || ! -f scripts/check-site.py ]]; then
  echo 'ERROR: Run from inside the GYM BEER website repository.' >&2
  exit 1
fi
if [[ "${GYM_BEER_DRY_RUN:-0}" != 1 ]]; then
  git rev-parse --show-toplevel >/dev/null || { echo 'ERROR: Not inside a Git repository.' >&2; exit 1; }
  if [[ "$(git branch --show-current)" != main ]]; then
    echo 'ERROR: Please switch to main before installing.' >&2
    exit 1
  fi
  if ! git diff --cached --quiet; then
    echo 'ERROR: There are already staged changes. Commit or unstage them first.' >&2
    exit 1
  fi
  # Avoid accidentally overwriting user edits to target files.
  if [[ -n "$(git diff --name-only -- index.html bauturi/index.html gustari/index.html galerie/index.html contact/index.html locatii/botanica/index.html locatii/buiucani/index.html assets/site.css assets/image-index.json README.md)" ]]; then
    echo 'ERROR: You have local changes to website pages. Commit or stash these first.' >&2
    exit 1
  fi
fi
mkdir -p assets/brand
cp "$(dirname "${BASH_SOURCE[0]}")"/assets/brand/* assets/brand/
python3 - <<'PY'
from pathlib import Path
import json,re
root=Path.cwd()
removed=('shop-interior-vertical','bottled-beer-display','beer-taps-detail','draft-selection-wall')
# Also preserve the earlier requested removal of four photographs when this
# package is installed on an older v1 Codespace.
for fn,replaces in {
 'index.html': {'beer-taps-detail':'beer-assortment-wall','draft-selection-wall':'holz-taps-snack'},
 'bauturi/index.html': {'beer-taps-detail':'beer-assortment-wall'},
 'locatii/botanica/index.html': {'shop-interior-vertical':'shop-interior-wide'}
}.items():
 p=root/fn; s=p.read_text(encoding='utf-8')
 for old,new in replaces.items():s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')

p=root/'galerie/index.html';s=p.read_text(encoding='utf-8')
for slug in removed:
  pattern=r'<a href="\.\./assets/images/'+re.escape(slug)+r'-1600\.webp" class="gallery-tile".*?</a>'
  s=re.sub(pattern,'',s,count=1)
s=s.replace('Toate cele 40 de fotografii din arhiva primită.','36 de fotografii selectate din arhiva GYM BEER.')
s=s.replace('<h2>Magazinele</h2><span>8 fotografii</span>','<h2>Magazinele</h2><span>7 fotografii</span>')
s=s.replace('<h2>Bere & băuturi</h2><span>16 fotografii</span>','<h2>Bere & băuturi</h2><span>13 fotografii</span>')
if s.count('class="gallery-tile"') != 36:raise SystemExit('ERROR: Expected 36 photos in gallery')
p.write_text(s,encoding='utf-8')

p=root/'assets/image-index.json'
a=json.loads(p.read_text(encoding='utf-8'))
a=[r for r in a if r.get('slug') not in removed]
if len(a) != 36:raise SystemExit('ERROR: Expected 36 photos in index')
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for slug in removed:
 for size in ('760','1600'):
  (root/'assets/images'/f'{slug}-{size}.webp').unlink(missing_ok=True)

new_css='''
/* Official GYM BEER identity — cropped from the approved logo artwork */
.site-header .brand.brand-custom,.site-footer .brand.brand-custom{display:inline-flex;align-items:center;flex:0 0 auto;line-height:0;letter-spacing:normal}
.brand-custom .brand-image{display:block;width:220px;height:auto;max-height:69px;object-fit:contain;object-position:left center}
.site-footer .brand-custom{background:#f7f6f2;padding:9px 12px;border-radius:5px;width:max-content}
.site-footer .brand-custom .brand-image{width:190px;max-height:64px}
@media(max-width:1050px){.site-header .brand-custom .brand-image{width:190px}}
@media(max-width:760px){.site-header .brand-custom .brand-image{width:190px;max-height:62px}}
@media(max-width:390px){.site-header .brand-custom .brand-image{width:170px}}
'''
css=root/'assets/site.css'; txt=css.read_text(encoding='utf-8')
if '/* Official GYM BEER identity' not in txt:
 css.write_text(txt.rstrip()+'\n'+new_css,encoding='utf-8')

header=r'<a class="brand" href="([^"]+)" aria-label="GYM BEER — pagina principală"><span class="brand-mark" aria-hidden="true">✳</span><span>GYM<span class="brand-light">BEER</span></span></a>'
footer=r'<a class="brand brand-footer" href="([^"]+)"><span class="brand-mark" aria-hidden="true">✳</span><span>GYM<span class="brand-light">BEER</span></span></a>'
for p in root.rglob('*.html'):
 if len(p.relative_to(root).parts)>4:continue
 s=p.read_text(encoding='utf-8'); pre='../'*(len(p.relative_to(root).parts)-1)
 if 'brand brand-custom' not in s:
  def repl_head(m):
   return '<a class="brand brand-custom" href="'+m.group(1)+'" aria-label="GYM BEER — pagina principală"><img class="brand-image" src="'+pre+'assets/brand/gym-beer-horizontal.webp" width="784" height="231" alt="Logo GYM BEER — Bere Vie" decoding="async"></a>'
  s,count=re.subn(header,repl_head,s)
  if count!=1:raise SystemExit('ERROR: Cannot update header in '+str(p))
  def repl_footer(m):
   return '<a class="brand brand-custom brand-footer" href="'+m.group(1)+'" aria-label="GYM BEER — pagina principală"><img class="brand-image" src="'+pre+'assets/brand/gym-beer-horizontal.webp" width="784" height="231" alt="Logo GYM BEER — Bere Vie" loading="lazy" decoding="async"></a>'
  s,count=re.subn(footer,repl_footer,s)
  if count!=1:raise SystemExit('ERROR: Cannot update footer in '+str(p))
 s,n=re.subn(r'<link rel="icon" type="image/svg\+xml" href="[^"]*favicon\.svg">',
   '<link rel="icon" href="'+pre+'assets/brand/favicon.ico" sizes="any"><link rel="apple-touch-icon" href="'+pre+'assets/brand/apple-touch-icon.png">',s)
 if n==0 and 'assets/brand/favicon.ico' not in s:raise SystemExit('ERROR: Cannot update favicon in '+str(p))
 for slug in removed:
  if slug in s:raise SystemExit('ERROR: Image still in page: '+str(p)+' '+slug)
 if 'assets/brand/gym-beer-horizontal.webp' not in s:raise SystemExit('ERROR: Logo missing: '+str(p))
 p.write_text(s,encoding='utf-8')

oldsvg=root/'favicon.svg'
if oldsvg.exists():oldsvg.unlink()
readme=root/'README.md';s=readme.read_text(encoding='utf-8')
s=s.replace('7 pagini, imagini reale din arhiva primită','7 pagini, 36 de fotografii din arhiva primită')
if '## Identitatea GYM BEER' not in s:
 s+='''\n## Identitatea GYM BEER\n\n- Logoul oficial este integrat în antet și subsol pe fiecare pagină.\n- Fișierele pentru web sunt în `assets/brand/`, inclusiv logoul complet, versiunea orizontală și favicon.\n- La actualizare în Codespaces: `git pull --ff-only origin main && bash scripts/start-preview.sh`.\n- Cele patru fotografii eliminate la cerere nu se mai află în galerie sau în `assets/images`.\n'''
readme.write_text(s,encoding='utf-8')
print('Updated official logo on all 7 pages; favicons installed; 36 approved gallery images remain.')
PY
python3 scripts/check-site.py
if [[ "${GYM_BEER_DRY_RUN:-0}" == 1 ]]; then
 echo 'PASS: Dry run. Did not commit or push.'
 exit 0
fi
# The original setup ZIP still contains the removed four photos. Remove the obsolete
# tracked archive to prevent accidentally restoring them later.
if git ls-files --error-unmatch GYM_BEER_Codespaces_Ready.zip >/dev/null 2>&1; then
 rm -f GYM_BEER_Codespaces_Ready.zip
 git add -u -- GYM_BEER_Codespaces_Ready.zip
fi
# The new brand assets and all relevant pages only. Never stage unrelated user files.
git add -- assets/brand assets/site.css assets/image-index.json index.html bauturi/index.html gustari/index.html galerie/index.html contact/index.html locatii/botanica/index.html locatii/buiucani/index.html README.md
if git ls-files --error-unmatch favicon.svg >/dev/null 2>&1; then
 git add -u -- favicon.svg
fi
git add -u -- assets/images
if git diff --cached --quiet; then
 echo 'No changes to publish (logo already installed).'
else
 git commit -m 'Add official GYM BEER logo across site and remove four rejected images'
 git push origin HEAD:main
fi
echo 'DONE. Refresh your Codespaces preview on port 3000 (hard-refresh if cached).'
