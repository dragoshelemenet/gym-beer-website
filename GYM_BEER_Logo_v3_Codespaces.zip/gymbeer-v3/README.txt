GYM BEER — Logo + Photos Update (v3)

Aplica noul logo GYM BEER pe toate cele 7 pagini, in header si footer, si seteaza favicon + Apple touch icon.
Include si eliminarea celor 4 fotografii respinse anterior, indiferent daca ai instalat deja update-ul v2.

INSTRUCTIUNI:
1. In Codespaces, intra in repo-ul dragoshelemenet/gym-beer-website (branch main).
2. Incarca GYM_BEER_Logo_v3_Codespaces.zip in directorul radacina al site-ului.
3. Ruleaza:
   git pull --ff-only origin main && unzip -o GYM_BEER_Logo_v3_Codespaces.zip -d . && bash gymbeer-v3/install.sh
4. Da refresh la preview-ul de pe portul 3000 (Shift+Reload daca logo-ul e in cache).

Se ruleaza verificarea HTML/assets; se face commit si push numai pentru fisierele modificate.
Pozele respinse nu mai sunt prezente; galeria are 36 imagini.
